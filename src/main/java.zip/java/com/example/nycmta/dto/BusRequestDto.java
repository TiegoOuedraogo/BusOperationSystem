package com.example.nycmta.dto;

import com.example.nycmta.entities.Schedule;
import lombok.*;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class BusRequestDto {
    private String busNumber;
    private Integer capacity;
    private List<Schedule> schedules;
}
