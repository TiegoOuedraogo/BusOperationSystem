package com.example.nycmta.service;

import com.example.nycmta.dto.BusRequestDto;
import com.example.nycmta.dto.BusResponseDto;
import com.example.nycmta.entities.Bus;
import com.example.nycmta.repository.BusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BusServiceImpl implements BusService {

    private final BusRepository busRepository;

    @Autowired
    public BusServiceImpl(BusRepository busRepository) {
        this.busRepository = busRepository;
    }

    @Override
    public BusResponseDto createBus(BusRequestDto busRequestDto) {
        Bus bus = mapToBus(busRequestDto);
        Bus savedBus = busRepository.save(bus);
        return mapToBusResponseDto(savedBus);
    }

    @Override
    public BusResponseDto getBusById(Long busId) {
        Bus bus = busRepository.findById(busId)
                .orElseThrow(() -> new ResourceNotFoundException("Bus", "busId", busId));
        return mapToBusResponseDto(bus);
    }

    @Override
    public List<BusResponseDto> getAllBuses() {
        List<Bus> buses = busRepository.findAll();
        return buses.stream()
                .map(this::mapToBusResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public BusResponseDto updateBus(Long busId, BusRequestDto busRequestDto) {
        Bus bus = busRepository.findById(busId)
                .orElseThrow(() -> new ResourceNotFoundException("Bus", "busId", busId));
        bus.setBusNumber(busRequestDto.getBusNumber());
        bus.setCapacity(busRequestDto.getCapacity());
        bus.setSchedules(busRequestDto.getSchedules());
        Bus updatedBus = busRepository.save(bus);
        return mapToBusResponseDto(updatedBus);
    }

    @Override
    public void deleteBus(Long busId) {
        Bus bus = busRepository.findById(busId)
                .orElseThrow(() -> new com.example.nycmta.service.ResourceNotFoundException("Bus", "busId", busId));
        busRepository.delete(bus);
    }

    // Mapping methods
    private BusResponseDto mapToBusResponseDto(Bus bus) {
        BusResponseDto busResponseDto = new BusResponseDto();
        busResponseDto.setBusId(bus.getBusId());
        busResponseDto.setBusNumber(bus.getBusNumber());
        busResponseDto.setCapacity(bus.getCapacity());
        busResponseDto.setSchedules(bus.getSchedules());
        return busResponseDto;
    }

    private Bus mapToBus(BusRequestDto busRequestDto) {
        Bus bus = new Bus();
        bus.setBusNumber(busRequestDto.getBusNumber());
        bus.setCapacity(busRequestDto.getCapacity());
        bus.setSchedules(busRequestDto.getSchedules());
        return bus;
    }

}
